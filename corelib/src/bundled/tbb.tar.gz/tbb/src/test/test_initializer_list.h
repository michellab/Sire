/*
    Copyright 2005-2013 Intel Corporation.  All Rights Reserved.

    This file is part of Threading Building Blocks.

    Threading Building Blocks is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
    version 2 as published by the Free Software Foundation.

    Threading Building Blocks is distributed in the hope that it will be
    useful, but WITHOUT ANY WARRANTY; without even the implied warranty
    of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Threading Building Blocks; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    As a special exception, you may use this file as part of a free software
    library without restriction.  Specifically, if other files instantiate
    templates or use macros or inline functions from this file, or you compile
    this file and link it with other files to produce an executable, this
    file does not by itself cause the resulting executable to be covered by
    the GNU General Public License.  This exception does not however
    invalidate any other reasons why the executable file might be covered by
    the GNU General Public License.
*/

#ifndef __TBB_test_initializer_list_H
#define __TBB_test_initializer_list_H
#include "tbb/tbb_config.h"


#if __TBB_INITIALIZER_LISTS_PRESENT
#include <initializer_list>
//TODO: split into set of tests
//TODO: add test for no leaks, and correct element lifetime
//the need for macro comes from desire to test different scenarios where initializer sequence is compile time constant
#define __TBB_TEST_INIT_LIST_SUITE(FUNC_NAME, CONTAINER, ELEMENT_TYPE, INIT_SEQ)                                                                  \
void FUNC_NAME(){                                                                                                                                 \
    typedef ELEMENT_TYPE element_type;                                                                                                            \
    typedef CONTAINER<element_type> container_type;                                                                                               \
    element_type test_seq[] = INIT_SEQ;                                                                                                           \
    container_type expected(test_seq,test_seq + array_length(test_seq));                                                                          \
                                                                                                                                                  \
    /*test for explicit contructor call*/                                                                                                         \
    container_type vd (INIT_SEQ,tbb::cache_aligned_allocator<int>());                                                                             \
    ASSERT(vd == expected,"initialization via explicit constructor call with init list failed");                                                  \
    /*test for explicit contructor call with std::initializer_list*/                                                                              \
                                                                                                                                                  \
    std::initializer_list<element_type> init_list = INIT_SEQ;                                                                                     \
    container_type v1 (init_list,tbb::cache_aligned_allocator<int>());                                                                            \
    ASSERT(v1 == expected,"initialization via explicit constructor call with std::initializer_list failed");                                      \
                                                                                                                                                  \
    /*implicit constructor call test*/                                                                                                            \
    container_type v = INIT_SEQ;                                                                                                                  \
    ASSERT(v == expected,"init list constructor failed");                                                                                         \
                                                                                                                                                  \
    /*assignment operator test*/                                                                                                                  \
    /*TODO: count created and destroyed injects to assert that no extra copy of vector was created implicitly*/                                   \
    container_type va;                                                                                                                            \
    va = INIT_SEQ;                                                                                                                                \
    ASSERT(va == expected,"init list operator= failed");                                                                                          \
                                                                                                                                                  \
    container_type vae;                                                                                                                           \
    vae.assign(INIT_SEQ);                                                                                                                         \
    ASSERT(vae == expected,"init list assign failed");                                                                                            \
}                                                                                                                                                 \

#endif //__TBB_INITIALIZER_LISTS_PRESENT
#endif //__TBB_test_initializer_list_H

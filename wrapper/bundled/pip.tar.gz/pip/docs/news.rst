====
News
====

Next Release
============

Beta and final releases of 1.5 are planned for end of 2013.

.. include:: ../CHANGES.txt

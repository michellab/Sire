pip
===

.. image:: https://pypip.in/v/pip/badge.png
        :target: https://crate.io/packages/pip

.. image:: https://secure.travis-ci.org/pypa/pip.png?branch=develop
   :target: http://travis-ci.org/pypa/pip

For documentation, see http://www.pip-installer.org
